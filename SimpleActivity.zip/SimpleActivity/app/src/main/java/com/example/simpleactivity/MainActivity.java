package com.example.simpleactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText yearInput;
    private TextView outputText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        yearInput = findViewById(R.id.input_tahun);
        outputText = findViewById(R.id.text_output);
    }

    public void handleSubmit(View view) {
        int tahun = Integer.parseInt(yearInput.getText().toString());
        if (tahun >= 1946 && tahun <= 1964){
            outputText.setText("Generasi Baby Boomers ");
        }
        else if( tahun >= 1981 && tahun <= 1994){
            outputText.setText("Generasi Y/Milenial ");
        }
        else if( tahun >= 1995 && tahun <= 2010){
            outputText.setText("Generasi Z ");
        }
        else if( tahun >= 2011 && tahun <= 2025){
            outputText.setText("Generasi Alpha ");
        }
        else{
            outputText.setText("Out of range ");
        }

    }
}